from setuptools import setup

setup(
    name='mikogpt_api',
    version='0.1.0',
    packages=['mikogpt_api'],
    url='',
    license='Apache 2.0',
    author='Alex Shveev',
    author_email='alexshveev@gmail.com',
    description='Api for mikogpt.ru service'
)
